import sys
import serial
import serial.tools.list_ports
import re
from datetime import datetime

from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

import pyqtgraph as pg


class SerialThread(QThread):

    data_received = pyqtSignal(str)

    def __init__(self, port):
        super().__init__()
        self.port = port
        self.running = True

    def run(self):

        ser = serial.Serial(self.port,115200,timeout=1)

        while self.running:

            if ser.in_waiting:

                data = ser.readline().decode(errors='ignore').strip()

                if data:
                    self.data_received.emit(data)

        ser.close()


class SensorCard(QFrame):

    def __init__(self,title):

        super().__init__()

        self.setStyleSheet("""
        QFrame{
            background:#2c2f48;
            border-radius:8px;
            padding:10px;
        }
        """)

        layout = QVBoxLayout()

        label_title = QLabel(title)
        label_title.setStyleSheet("color:#bbb;font-size:14px")

        self.value = QLabel("--")
        self.value.setStyleSheet("font-size:22px;font-weight:bold;color:#00ffc3")

        layout.addWidget(label_title)
        layout.addWidget(self.value)

        self.setLayout(layout)


class LoRaGUI(QMainWindow):

    def __init__(self):

        super().__init__()

        self.setWindowTitle("LoRa Telemetry Dashboard")
        self.resize(1300,850)

        self.thread=None

        self.x=[]
        self.suhu=[]
        self.hum=[]
        self.soil=[]
        self.cahaya=[]

        self.initUI()
        self.loadPorts()


    def initUI(self):

        central = QWidget()
        self.setCentralWidget(central)

        mainLayout = QVBoxLayout()
        central.setLayout(mainLayout)

        # TITLE

        title = QLabel("LORA TELEMETRY MONITORING SYSTEM")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size:28px;font-weight:bold;color:white")

        mainLayout.addWidget(title)

        # CONTROL PANEL

        control = QHBoxLayout()

        self.portBox = QComboBox()

        refreshBtn = QPushButton("Refresh")
        refreshBtn.clicked.connect(self.loadPorts)

        self.connectBtn = QPushButton("Connect")
        self.connectBtn.clicked.connect(self.toggleConnection)

        control.addWidget(QLabel("Serial Port:"))
        control.addWidget(self.portBox)
        control.addWidget(refreshBtn)
        control.addWidget(self.connectBtn)

        control.addStretch()

        mainLayout.addLayout(control)

        # SENSOR CARDS

        cardLayout = QHBoxLayout()

        self.card_suhu = SensorCard("Temperature (°C)")
        self.card_hum = SensorCard("Humidity (%)")
        self.card_soil = SensorCard("Soil Moisture")
        self.card_cahaya = SensorCard("Light Intensity")
        self.card_status = SensorCard("Status")

        cardLayout.addWidget(self.card_suhu)
        cardLayout.addWidget(self.card_hum)
        cardLayout.addWidget(self.card_soil)
        cardLayout.addWidget(self.card_cahaya)
        cardLayout.addWidget(self.card_status)

        mainLayout.addLayout(cardLayout)

        # TABLE

        self.table = QTableWidget()
        self.table.setColumnCount(6)

        self.table.setHorizontalHeaderLabels([
            "Time","Temp","Humidity","Soil","Light","Status"
        ])

        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        mainLayout.addWidget(self.table)

        # GRAPH

        graphLayout = QGridLayout()

        self.graph_suhu = pg.PlotWidget(title="Temperature")
        self.graph_hum = pg.PlotWidget(title="Humidity")
        self.graph_soil = pg.PlotWidget(title="Soil Moisture")
        self.graph_cahaya = pg.PlotWidget(title="Light")

        graphLayout.addWidget(self.graph_suhu,0,0)
        graphLayout.addWidget(self.graph_hum,0,1)
        graphLayout.addWidget(self.graph_soil,1,0)
        graphLayout.addWidget(self.graph_cahaya,1,1)

        mainLayout.addLayout(graphLayout)

        # background grafik putih

        self.graph_suhu.setBackground('w')
        self.graph_hum.setBackground('w')
        self.graph_soil.setBackground('w')
        self.graph_cahaya.setBackground('w')

        # grid grafik

        self.graph_suhu.showGrid(x=True,y=True)
        self.graph_hum.showGrid(x=True,y=True)
        self.graph_soil.showGrid(x=True,y=True)
        self.graph_cahaya.showGrid(x=True,y=True)

        # garis grafik

        self.line_suhu = self.graph_suhu.plot(pen=pg.mkPen('#ff4d4d',width=3))
        self.line_hum = self.graph_hum.plot(pen=pg.mkPen('#4da6ff',width=3))
        self.line_soil = self.graph_soil.plot(pen=pg.mkPen('#2ecc71',width=3))
        self.line_cahaya = self.graph_cahaya.plot(pen=pg.mkPen('#f1c40f',width=3))

        # STATUS

        self.statusBar().showMessage("Disconnected")

        # STYLE

        self.setStyleSheet("""

        QMainWindow{
            background:#1e1f33;
            color:white;
        }

        QLabel{
            color:white;
        }

        QPushButton{
            background:#3a3d5c;
            color:white;
            padding:6px;
            border-radius:4px;
        }

        QPushButton:hover{
            background:#50537a;
        }

        QTableWidget{
            background:white;
            color:black;
            gridline-color:#ccc;
        }

        QHeaderView::section{
            background:#3a3d5c;
            color:white;
            padding:4px;
            font-weight:bold;
        }

        """)


    def loadPorts(self):

        self.portBox.clear()

        ports = serial.tools.list_ports.comports()

        for port in ports:
            self.portBox.addItem(port.device)


    def toggleConnection(self):

        if self.thread and self.thread.isRunning():

            self.thread.running=False
            self.thread.quit()
            self.thread.wait()

            self.thread=None
            self.connectBtn.setText("Connect")
            self.statusBar().showMessage("Disconnected")

            return

        port = self.portBox.currentText()

        if not port:
            QMessageBox.warning(self,"Error","Port belum dipilih")
            return

        self.thread = SerialThread(port)
        self.thread.data_received.connect(self.processData)
        self.thread.start()

        self.connectBtn.setText("Disconnect")
        self.statusBar().showMessage("Connected to "+port)


    def processData(self,data):

        pattern = r"Suhu:(.*),Hum:(.*),Soil:(.*),Cahaya:(.*),Status:(.*)"

        match = re.search(pattern,data)

        if not match:
            return

        suhu = float(match.group(1))
        hum = float(match.group(2))
        soil = int(match.group(3))
        cahaya = int(match.group(4))
        status = int(match.group(5))

        time = datetime.now().strftime("%H:%M:%S")

        # update cards

        self.card_suhu.value.setText(str(suhu))
        self.card_hum.value.setText(str(hum))
        self.card_soil.value.setText(str(soil))
        self.card_cahaya.value.setText(str(cahaya))
        self.card_status.value.setText(str(status))

        # table

        row = self.table.rowCount()
        self.table.insertRow(row)

        self.table.setItem(row,0,QTableWidgetItem(time))
        self.table.setItem(row,1,QTableWidgetItem(str(suhu)))
        self.table.setItem(row,2,QTableWidgetItem(str(hum)))
        self.table.setItem(row,3,QTableWidgetItem(str(soil)))
        self.table.setItem(row,4,QTableWidgetItem(str(cahaya)))
        self.table.setItem(row,5,QTableWidgetItem(str(status)))

        self.table.scrollToBottom()

        self.updateGraph(suhu,hum,soil,cahaya)


    def updateGraph(self,suhu,hum,soil,cahaya):

        index=len(self.x)

        self.x.append(index)
        self.suhu.append(suhu)
        self.hum.append(hum)
        self.soil.append(soil)
        self.cahaya.append(cahaya)

        if len(self.x)>50:

            self.x=self.x[-50:]
            self.suhu=self.suhu[-50:]
            self.hum=self.hum[-50:]
            self.soil=self.soil[-50:]
            self.cahaya=self.cahaya[-50:]

        self.line_suhu.setData(self.x,self.suhu)
        self.line_hum.setData(self.x,self.hum)
        self.line_soil.setData(self.x,self.soil)
        self.line_cahaya.setData(self.x,self.cahaya)


if __name__ == "__main__":

    app = QApplication(sys.argv)

    window = LoRaGUI()
    window.show()

    sys.exit(app.exec_())